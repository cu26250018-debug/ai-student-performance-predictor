# AI Student Performance Predictor 🎓

A beginner-friendly Artificial Intelligence / Machine Learning project for a first-year B.Tech student. It estimates a student's possible final score from study habits and academic indicators, using a Random Forest regression model and a simple Streamlit web interface.

> **Important:** The included CSV contains synthetic, computer-generated examples. It is only for learning and demonstration; it is not real student data and should not be used for real academic decisions.

## Features

- Interactive web app with sliders for student inputs
- Machine-learning model using `RandomForestRegressor`
- Train/test split and evaluation with MAE and R²
- Dataset preview
- Feature-importance chart
- Beginner-friendly Python code and comments

## Inputs used

- Study hours per day
- Attendance percentage
- Previous exam score
- Sleep hours per night
- Assignments completed out of 10

## Project structure

```text
ai_student_performance_predictor/
├── app.py
├── data/
│   └── student_performance.csv
├── requirements.txt
├── .gitignore
└── README.md
```

## Run the project locally

### 1. Install Python

Use Python 3.10 or newer. Check your version:

```bash
python --version
```

### 2. Download or clone the repository

After uploading this project to GitHub, clone it with:

```bash
git clone https://github.com/YOUR-USERNAME/ai-student-performance-predictor.git
cd ai-student-performance-predictor
```

Or download the ZIP and extract it.

### 3. Create a virtual environment (recommended)

**Windows:**
```bash
python -m venv .venv
.venv\Scripts\activate
```

**macOS/Linux:**
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 4. Install dependencies

```bash
pip install -r requirements.txt
```

### 5. Start the app

```bash
streamlit run app.py
```

The app should open in your browser. If it does not, Streamlit prints a local address in the terminal.

## How it works

1. The CSV dataset is loaded using pandas.
2. The data is divided into training and testing sets.
3. A Random Forest regression model learns patterns between the input features and the target score.
4. The model is evaluated using Mean Absolute Error (MAE) and R².
5. The app takes new input values and displays the model's estimated score.
6. Feature importance is visualized to help explore which inputs the model relied on most.

## AI/ML concepts demonstrated

- Supervised learning
- Regression
- Training and testing data
- Random Forest
- Model evaluation
- Feature importance
- Data visualization

## Limitations and responsible use

- The dataset is synthetic and does not represent real students.
- The learned patterns are intentionally simplified for a classroom demonstration.
- Real performance depends on many factors not represented here.
- Predictions can be inaccurate. Do not use this project to grade, rank, admit, or penalize students.

## Possible future improvements

- Replace the synthetic data with a properly licensed, anonymized real dataset.
- Compare Linear Regression, Decision Tree, and Random Forest models.
- Add cross-validation and more detailed error analysis.
- Improve accessibility and add a mobile-friendly interface.
- Add automated tests and a model-training script.

## Technologies

- Python
- pandas
- scikit-learn
- Streamlit
- Matplotlib

## Author

**Your Name** — B.Tech First Year

Before submitting, replace `Your Name` with your own name and add your course/college details if required.

## License

This project is released under the MIT License. See `LICENSE`.
